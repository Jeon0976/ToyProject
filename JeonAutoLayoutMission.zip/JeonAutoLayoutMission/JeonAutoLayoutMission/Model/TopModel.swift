//
//  TopModel.swift
//  JeonAutoLayoutMission
//
//  Created by 전성훈 on 2023/08/01.
//

import UIKit

struct TopModel {
    let title: String
    let subTitle: String
    let image: UIImage
}
