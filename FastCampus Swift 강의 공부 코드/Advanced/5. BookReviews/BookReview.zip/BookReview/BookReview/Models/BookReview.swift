//
//  BookReview.swift
//  BookReview
//
//  Created by 전성훈 on 2022/12/22.
//

import Foundation

struct BookReview: Codable {
    let title : String
    let author : String
    let contents: String
    let imageURL : URL?
}
