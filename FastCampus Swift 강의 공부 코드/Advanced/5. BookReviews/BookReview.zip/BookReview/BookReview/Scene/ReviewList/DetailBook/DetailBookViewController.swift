//
//  DetailBookViewController.swift
//  BookReview
//
//  Created by 전성훈 on 2022/12/22.
//

import UIKit
import SnapKit
import Kingfisher

class DetailBookViewController : UIViewController {
    private lazy var presenter = DetailBookPresenter(viewController: self)
    
    private let delegate : ReviewListDelegate
    
    init(delegate: ReviewListDelegate) {
        self.delegate = delegate
        
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private var bookReview : BookReview?
    
    private let titleButton: UIButton = {
        let button = UIButton()
        button.setTitle("책 제목", for: .normal)
        button.setTitleColor(.tertiaryLabel, for: .normal)
        // 왼쪽 정렬
        button.contentHorizontalAlignment = .left
        button.titleLabel?.font = .systemFont(ofSize: 23.0, weight: .bold)

        return button
    }()
     
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        print(bookReview)
    }
}

extension DetailBookViewController : DetailBookProtocol {
    func setUp() {
        view.backgroundColor = .systemBackground
        [titleButton].forEach {
            view.addSubview($0)
        }

        titleButton.snp.makeConstraints {
            $0.leading.trailing.equalToSuperview().inset(20.0)
            $0.top.equalTo(view.safeAreaLayoutGuide).offset(20.0)
        }

    }
    
    
    func sett(_ bookReview: BookReview) {
        titleButton.setTitle(bookReview.title, for: .normal)
        titleButton.setTitleColor(.label, for: .normal)
    }
}


extension DetailBookViewController: ReviewListDelegate {
    func selectedBook(_ book: BookReview) {
        self.bookReview = book
        presenter.updateView(book)
        titleButton.setTitle(book.title, for: .normal)
        titleButton.setTitleColor(.label, for: .normal)
    }
}

