//
//  DetailBookPresenter.swift
//  BookReview
//
//  Created by 전성훈 on 2022/12/22.
//

import UIKit

protocol DetailBookProtocol {
    func setUp()
    func sett(_ bookReview: BookReview)
}

final class DetailBookPresenter {
    private let viewController : DetailBookProtocol
    
    init(viewController: DetailBookProtocol) {
        self.viewController = viewController
    }
    
    func viewDidLoad() {
        viewController.setUp()
    }
    
    func updateView(_ bookReview: BookReview) {
        viewController.sett(bookReview)
    }
}
