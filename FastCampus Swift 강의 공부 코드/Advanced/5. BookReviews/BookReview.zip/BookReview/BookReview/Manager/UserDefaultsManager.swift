//
//  UserDefaultsManager.swift
//  BookReview
//
//  Created by 전성훈 on 2022/12/22.
//

import Foundation

protocol UserDefaultsManagerProtocol {
    func getReviews() -> [BookReview]
    func setReviews(_ newValues: BookReview)
}

// Test 작성을 조금 더 쉽게 하기위해 protocol 작성
struct UserDefaultsManager: UserDefaultsManagerProtocol {
    enum Key: String {
        case review
    }
    
    func getReviews() -> [BookReview] {
        guard let data = UserDefaults.standard.data(forKey: Key.review.rawValue) else {return []}
        
        // what is ProptertyListDecoder
        return (try? PropertyListDecoder().decode([BookReview].self, from: data)) ?? []
    }
    
    func setReviews(_ newValues: BookReview) {
        var currentReviews: [BookReview] = getReviews()
        currentReviews.insert(newValues, at: 0)
        
        UserDefaults.standard.set(try? PropertyListEncoder().encode(currentReviews), forKey: Key.review.rawValue)
    }
    
    
}
